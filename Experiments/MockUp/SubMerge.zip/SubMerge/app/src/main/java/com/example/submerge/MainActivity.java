package com.example.submerge;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.widget.Toast;

import com.mongodb.stitch.android.core.Stitch;
import com.mongodb.stitch.android.core.StitchAppClient;
import com.mongodb.stitch.android.services.mongodb.remote.RemoteMongoClient;
import com.mongodb.stitch.android.services.mongodb.remote.RemoteMongoCollection;
import com.mongodb.stitch.core.auth.providers.anonymous.AnonymousCredential;
import com.mongodb.stitch.core.auth.providers.google.GoogleCredential;

import static com.google.android.gms.auth.api.Auth.GOOGLE_SIGN_IN_API;


import com.mongodb.stitch.core.auth.providers.facebook.FacebookCredential;
import com.mongodb.stitch.core.internal.common.BsonUtils;

import org.bson.codecs.configuration.CodecRegistries;

public class MainActivity extends AppCompatActivity {
    private static final String TAG = SubListActivity.class.getSimpleName();
    private SubAdapter subAdapter;
    private RemoteMongoCollection<SubItem> items;
    private String userId;

    public static StitchAppClient client;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        client = Stitch.getDefaultAppClient();

        final RemoteMongoClient mongoClient = client.getServiceClient(RemoteMongoClient.factory, "mongodb-atlas");

        items = mongoClient
                .getDatabase(SubItem.SUB_DATABASE)
                .getCollection(SubItem.SUB_ITEMS_COLLECTION, SubItem.class)
                .withCodecRegistry(CodecRegistries.fromRegistries(
                        BsonUtils.DEFAULT_CODEC_REGISTRY,
                        CodecRegistries.fromCodecs(SubItem.codec)));

        final RecyclerView subRecyclerView = findViewById(R.id.rv_sub_items);
        final RecyclerView.LayoutManager subLayoutManager = new LinearLayoutManager(this);
        subRecyclerView.setLayoutManager(subLayoutManager);

        subAdapter = new SubAdapter(
                new ArrayList<>(),
                new SubAdapter.ItemUpdater() {
                    @Override
                    public void updateChecked(final ObjectId itemId, final boolean isChecked) {
                        final Document updateDoc =
                                new Document("$set", new Document(SubItem.Fields.CHECKED, isChecked));
                        items.updateOne(new Document("_id", itemId), updateDoc);
                    }

                    @Override
                    public void updateTask(final ObjectId itemId, final String currentTask) {
                        showEditItemDialog(itemId, currentTask);
                    }
                });
        subRecyclerView.setAdapter(subAdapter);
        doLogin();
    }
}
